from django.shortcuts import render
from django.http import HttpResponse


def aboutMe(request):
    return render(request, 'aboutMe.html' )
